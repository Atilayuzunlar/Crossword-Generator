export class Start extends Phaser.Scene {

    constructor() {
        super('Start');
    }

    preload() {
      
    }

  create() {
    function refresh () { 
            const words = ["ATILAY", "ATLI", "ALTI", "YALI", "YAT", "TAY"];
            const gridSize = 8;
            let grid, placedWords;

            function shuffle(array) {
                return array.sort(() => Math.random() - 0.5);
            }

            function createEmptyGrid() {
                return Array.from({ length: gridSize }, () => Array(gridSize).fill(""));
            }

            function isInside(x, y) {
                return x >= 0 && y >= 0 && x < gridSize && y < gridSize;
            }

            function canPlaceStrict(word, x, y, dir) {
            for (let i = 0; i < word.length; i++) {
                const nx = dir === "horizontal" ? x + i : x;
                const ny = dir === "vertical" ? y + i : y;

                if (!isInside(nx, ny)) return false;

                const existing = grid[ny][nx];
                const letter = word[i];

                if (existing && existing !== letter) return false;

                if (!existing) {
                const neighbors = [
                    [nx - 1, ny],
                    [nx + 1, ny],
                    [nx, ny - 1],
                    [nx, ny + 1],
                ];

                for (const [cx, cy] of neighbors) {
                    if (
                        isInside(cx, cy) &&
                        grid[cy][cx] &&
                        !(dir === "horizontal" && cx === nx - 1) &&
                        !(dir === "horizontal" && cx === nx + 1) &&
                        !(dir === "vertical" && cy === ny - 1) &&
                        !(dir === "vertical" && cy === ny + 1)
                    ) {
                    return false;
                    }
                }
                }
            }

            const beforeX = dir === "horizontal" ? x - 1 : x;
            const beforeY = dir === "vertical" ? y - 1 : y;
            const afterX = dir === "horizontal" ? x + word.length : x;
            const afterY = dir === "vertical" ? y + word.length : y;

            if ((isInside(beforeX, beforeY) && grid[beforeY][beforeX]) ||
                (isInside(afterX, afterY) && grid[afterY][afterX])) {
                return false;
            }

            return true;
            }

            function placeWord(word, x, y, dir) {
                for (let i = 0; i < word.length; i++) {
                    const nx = dir === "horizontal" ? x + i : x;
                    const ny = dir === "vertical" ? y + i : y;
                    grid[ny][nx] = word[i];
                }
                placedWords.push({ word, x, y, dir });
            }

            function placeWithIntersection(word) {
                const directions = ["horizontal", "vertical"];
                const placedShuffled = shuffle([...placedWords]);

                for (const placed of placedShuffled) {
                    for (let i = 0; i < placed.word.length; i++) {
                        for (let j = 0; j < word.length; j++) {
                            if (placed.word[i] !== word[j]) continue;

                            const px = placed.dir === "horizontal" ? placed.x + i : placed.x;
                            const py = placed.dir === "vertical" ? placed.y + i : placed.y;
                            const newDir = placed.dir === "horizontal" ? "vertical" : "horizontal";
                            const newX = newDir === "horizontal" ? px - j : px;
                            const newY = newDir === "vertical" ? py - j : py;

                            if (canPlaceStrict(word, newX, newY, newDir)) {
                                placeWord(word, newX, newY, newDir);
                                return true;
                            }
                        }
                    }
                }

                return false;
            }

            function tryPlaceAllWords() {
                for (let attempt = 0; attempt < 1000; attempt++) {
                    grid = createEmptyGrid();
                    placedWords = [];

                    const shuffled = shuffle([...words]);
                    const startWord = shuffled[0];
                    const startX = Math.floor(Math.random() * (gridSize - startWord.length));
                    const startY = Math.floor(Math.random() * gridSize);
                    placeWord(startWord, startX, startY, "horizontal");

                    let success = true;

                    for (let i = 1; i < shuffled.length; i++) {
                        if (!placeWithIntersection(shuffled[i])) {
                            success = false;
                            break;
                        }
                    }

                    if (success) return true;
                }

                return false;
            }

            function renderGrid() {
                const gridDiv = document.getElementById("grid");
                gridDiv.innerHTML = "";

                for (let y = 0; y < gridSize; y++) {
                    for (let x = 0; x < gridSize; x++) {
                    const cell = document.createElement("div");
                    cell.className = grid[y][x] ? "cell" : "cell empty";
                    cell.textContent = grid[y][x] || "";
                    gridDiv.appendChild(cell);
                    }
                }
            }

            if (tryPlaceAllWords()) {
                renderGrid();
            } else {
                alert("Kelimeler yerleştirilemedi!");
            }
        }

        refresh();
        document.getElementById("generateBtn").addEventListener("click", refresh);

    

          


    }
}





  
  
